<?php $__env->startSection('title', 'Dashboard - Daftar Jadwal Ekstrakulikuler'); ?>

<?php $__env->startPush('css'); ?>
    <link href="<?php echo e(asset('datatables')); ?>/datatables.min.css" rel="stylesheet">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content-title', 'Dashboard - Daftar Jadwal Ekstrakulikuler'); ?>


<?php $__env->startSection('main-content'); ?>

    <div class="row mt-1 mb-1">
        <div class="col-sm-12 col-md-12 col-lg-12">
            <?php if(session('status')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>
        </div>
    </div>

    <div class="row">
        <div class="col-sm-12 col-md-12 col-lg-12">
            <div class="card mb-3">
                <div class="card-body">
                    <div class="container">
                        <div class="row">
                            <div class="col-sm-6 col-md-6 col-lg-6">
                                <h4>
                                    <b>
                                        Daftar Jadwal Ekstrakulikuler
                                    </b>
                                </h4>
                            </div>
                            <div class="col-sm-6 col-md-6 col-lg-6 d-flex justify-content-end">
                                <button type="button" class="btn btn-md btn-info" data-toggle="modal"
                                    data-target="#modaltambah">
                                    Tambah Jadwal
                                </button>
                            </div>
                        </div>

                        
                        <div class="modal fade" id="modaltambah" tabindex="-1" role="dialog"
                            aria-labelledby="exampleModalLabelLogout" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabelLogout">
                                            Tambah Jadwal
                                        </h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <form action="<?php echo e(route('tambah-jadwal')); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <div class="modal-body">

                                            <div class="row">
                                                <div class="col-sm-6 col-md-6 col-lg-6">
                                                    <div class="form-group">
                                                        <label for="exampleInputEmail1">Tempat Kegiatan</label>
                                                        <input type="text" class="form-control" id="exampleInputEmail1"
                                                            aria-describedby="emailHelp"
                                                            placeholder="contoh : Gedung A SMADA" name="jadwal_tempat">
                                                    </div>
                                                </div>
                                                <div class="col-sm-6 col-md-6 col-lg-6">
                                                    <div class="form-group">
                                                        <label for="exampleFormControlSelect1">Ekstrakulikuler</label>
                                                        <select class="form-control" id="exampleFormControlSelect1"
                                                            name="eskul_id">

                                                            <?php $__currentLoopData = $eskul; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $j): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($j->id); ?>"><?php echo e($j->eskul_nama); ?>

                                                                </option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                        </select>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="row">
                                                <div class="col-sm-12 col-md-12 col-lg-12">
                                                    <div class="form-group">
                                                        <label for="exampleFormControlTextarea1">Keterangan</label>
                                                        <textarea class="form-control" id="exampleFormControlTextarea1" rows="3" name="jadwal_keterangan"></textarea>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="row">
                                                <div class="col-sm-6 col-md-6 col-lg-6">
                                                    <div class="form-group">
                                                        <label for="exampleFormControlTextarea1">Tanggal</label>
                                                        <input type="date" class="form-control" id="exampleInputEmail1"
                                                            aria-describedby="emailHelp" name="jadwal_tanggal">
                                                    </div>
                                                </div>
                                                <div class="col-sm-6 col-md-6 col-lg-6">
                                                    <div class="form-group">
                                                        <label for="exampleFormControlTextarea1">Waktu</label>
                                                        <input type="time" class="form-control" id="exampleInputEmail1"
                                                            aria-describedby="emailHelp" name="jadwal_waktu">
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-info"
                                                data-dismiss="modal">Batalkan</button>
                                            <button type="submit" class="btn btn-success">Tambah</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>

                        <hr />
                        <div class="row">
                            <div class="table-responsive">
                                <table id="example" class="display table-bordered" style="width:100%">
                                    <thead class="thead-dark">
                                        <tr>
                                            <th>No.</th>
                                            <th>Ekstrakulikuler</th>
                                            <th>Tempat</th>
                                            <th>Tanggal</th>
                                            <th>Waktu</th>
                                            <th>Kelola</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $jadwal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td class="text-center"><?php echo e($loop->iteration); ?></td>

                                                <td><?php echo e($item->eskul->eskul_nama); ?></td>
                                                <td><?php echo e($item->jadwal_tempat); ?></td>
                                                <td><?php echo e(date('d-m-Y', strtotime($item->jadwal_waktu))); ?></td>
                                                <td><?php echo e(date('H:i', strtotime($item->jadwal_waktu))); ?></td>

                                                <td>
                                                    <div class="row">
                                                        <div
                                                            class="col-sm-12 col-md-12 col-lg-12 d-flex justify-content-center mx-auto">
                                                            <button
                                                                onclick="location.href = '<?php echo e(route('lihat-absen', $item->id)); ?>';"
                                                                class="btn btn-sm btn-primary mr-1">Lihat Absen</button>
                                                            <?php if($users->login_level == 'admin'): ?>
                                                                <button href="#"
                                                                    class="btn btn-sm btn-success mr-1" data-toggle="modal"
                                                                    data-target="#modalubah<?php echo e($item->id); ?>">Ubah</button>
                                                                <button href="#" class="btn btn-sm btn-danger"
                                                                    data-toggle="modal"
                                                                    data-target="#hapusModal<?php echo e($item->id); ?>">Hapus</button>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>

                                            
                                            <div class="modal fade" id="hapusModal<?php echo e($item->id); ?>" tabindex="-1"
                                                role="dialog" aria-labelledby="exampleModalLabelLogout"
                                                aria-hidden="true">
                                                <div class="modal-dialog" role="document">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title" id="exampleModalLabelLogout">
                                                                Konfirmasi
                                                                Tindakan Penghapusan!</h5>
                                                            <button type="button" class="close" data-dismiss="modal"
                                                                aria-label="Close">
                                                                <span aria-hidden="true">&times;</span>
                                                            </button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <p>Apakah anda yakin ingin menghapus Data Jadwal Ekstrakulikuler
                                                                <b><?php echo e($item->eskul->eskul_nama); ?></b> di
                                                                <b><?php echo e($item->jadwal_tempat); ?></b> ini ?
                                                            </p>
                                                        </div>
                                                        <div class="modal-footer">

                                                            <form action="<?php echo e(route('hapus-jadwal', $item->id)); ?>"
                                                                method="POST">
                                                                <?php echo csrf_field(); ?>
                                                                <input type="hidden" name="logoutrequest">
                                                                <button type="button" class="btn btn-warning"
                                                                    data-dismiss="modal">Batalkan</button>
                                                                <button type="submit"
                                                                    class="btn btn-danger">Hapus</button>
                                                            </form>

                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            

                                            
                                            <div class="modal fade" id="modalubah<?php echo e($item->id); ?>" tabindex="-1" role="dialog"
                                                aria-labelledby="exampleModalLabelLogout" aria-hidden="true">
                                                <div class="modal-dialog" role="document">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title" id="exampleModalLabelLogout">
                                                                Ubah Jadwal
                                                            </h5>
                                                            <button type="button" class="close" data-dismiss="modal"
                                                                aria-label="Close">
                                                                <span aria-hidden="true">&times;</span>
                                                            </button>
                                                        </div>
                                                        <form action="<?php echo e(route('ubah-jadwal', $item->id)); ?>" method="POST">
                                                            <?php echo csrf_field(); ?>
                                                            <div class="modal-body">

                                                                <div class="row">
                                                                    <div class="col-sm-6 col-md-6 col-lg-6">
                                                                        <div class="form-group">
                                                                            <label for="exampleInputEmail1">Tempat
                                                                                Kegiatan</label>
                                                                            <input type="text" class="form-control"
                                                                                id="exampleInputEmail1"
                                                                                aria-describedby="emailHelp"
                                                                                placeholder="contoh : Gedung A SMADA"
                                                                                name="jadwal_tempat" value="<?php echo e($item->jadwal_tempat); ?>">
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-sm-6 col-md-6 col-lg-6">
                                                                        <div class="form-group">
                                                                            <label
                                                                                for="exampleFormControlSelect1">Ekstrakulikuler</label>
                                                                            <select class="form-control"
                                                                                id="exampleFormControlSelect1"
                                                                                name="eskul_id" value="<?php echo e($item->eskul_id); ?>">
                                                                                <option default value="<?php echo e($item->eskul_id); ?>"><?php echo e($item->eskul->eskul_nama); ?></option>
                                                                                <?php $__currentLoopData = $eskul; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $j): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                    <option value="<?php echo e($j->id); ?>">
                                                                                        <?php echo e($j->eskul_nama); ?>

                                                                                    </option>
                                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                                            </select>
                                                                        </div>
                                                                    </div>
                                                                </div>

                                                                <div class="row">
                                                                    <div class="col-sm-12 col-md-12 col-lg-12">
                                                                        <div class="form-group">
                                                                            <label
                                                                                for="exampleFormControlTextarea1">Keterangan</label>
                                                                            <textarea class="form-control" id="exampleFormControlTextarea1" rows="3" name="jadwal_keterangan"></textarea value="<?php echo e($item->jadwal_keterangan); ?>">
                                                                        </div>
                                                                    </div>
                                                                </div>

                                                                <div class="row">
                                                                    <div class="col-sm-6 col-md-6 col-lg-6">
                                                                        <div class="form-group">
                                                                            <label
                                                                                for="exampleFormControlTextarea1">Tanggal</label>
                                                                            <input type="date" class="form-control"
                                                                                id="exampleInputEmail1"
                                                                                aria-describedby="emailHelp"
                                                                                name="jadwal_tanggal" value="<?php echo e($item->jadwal_tanggal); ?>">
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-sm-6 col-md-6 col-lg-6">
                                                                        <div class="form-group">
                                                                            <label
                                                                                for="exampleFormControlTextarea1">Waktu</label>
                                                                            <input type="time" class="form-control"
                                                                                id="exampleInputEmail1"
                                                                                aria-describedby="emailHelp"
                                                                                name="jadwal_waktu" value="<?php echo e($item->jadwal_waktu); ?>">
                                                                        </div>
                                                                    </div>
                                                                </div>

                                                                <div class="row">
                                                                    <div class="col-sm-12 col-md-12 col-lg-12">
                                                                        <p>
                                                                            <span style="color:red;"> NOTE </span> : Biarkan kosong pada Tanggal dan Waktu jika tanggal dan waktu tidak diubah, sebaliknya anda harus mengganti kedua tanggal dan waktu untuk mengubah data jadwal.
                                                                        </p>
                                                                    </div>
                                                                </div>

                                                            </div>
                                                            <div class="modal-footer">
                                                                <button type="button" class="btn btn-info"
                                                                    data-dismiss="modal">Batalkan</button>
                                                                <button type="submit"
                                                                    class="btn btn-success">Tambah</button>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                            


                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php $__env->startPush('js'); ?>
    <script src="<?php echo e(asset('datatables')); ?>/datatables.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#example').DataTable();
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.dashboard-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\fathurwalkers\Desktop\htdocs\aplikasi-eskul\resources\views/dashboard/daftar-jadwal.blade.php ENDPATH**/ ?>