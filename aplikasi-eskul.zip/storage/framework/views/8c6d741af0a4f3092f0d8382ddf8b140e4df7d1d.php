<?php $__env->startSection('tombol-keluar'); ?>
    <div class="tombol-keluar mt-2">
        <a href="<?php echo e(route('client-daftar-jadwal')); ?>">
            <i class="bi bi-arrow-left-circle" style="font-size: 2rem; margin-right: 30px;"></i>
        </a>
        <h5 style="display: inline-block;">Jadwal Ekstrakulikuler - <?php echo e($eskul->eskul_nama); ?></h5>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
    <div class="container">
        <div class="row mt-4 justify-content-center">

            <?php $__currentLoopData = $jadwal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-11 mb-5 shadow-sm">
                <div class="card border-primary mb-3">
                    <div class="card-header border-primary card-title font-weight-bold"><?php echo e(date("D", strtotime($items->jadwal_waktu))); ?>, <?php echo e(date("d M Y", strtotime($items->jadwal_waktu))); ?></div>
                    <div class="card-body text-primary">
                        <h5 class="card-title"><?php echo e($items->jadwal_tempat); ?></h5>
                        <p class="card-text h6">
                            <?php echo e($items->jadwal_keterangan); ?>

                        </p>
                    </div>
                    <div class="card-footer bg-transparent border-primary"><?php echo e(date("H:i", strtotime($items->jadwal_waktu))); ?></div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>

        <br />
        <br />
        <br />
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.client-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\fathurwalkers\Desktop\htdocs\aplikasi-eskul\resources\views/client/client-lihat-jadwal.blade.php ENDPATH**/ ?>