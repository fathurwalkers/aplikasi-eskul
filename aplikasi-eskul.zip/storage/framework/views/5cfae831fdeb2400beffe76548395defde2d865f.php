<?php $__env->startSection('tombol-keluar'); ?>
    <div class="tombol-keluar mt-2">
        <a href="<?php echo e(route('client')); ?>">
            <i class="bi bi-arrow-left-circle" style="font-size: 2rem; margin-right: 30px;"></i>
        </a>
        <h5 style="display: inline-block;">Daftar Hadir</h5>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>

    <div class="row mt-1 mb-1">
        <div class="col-sm-12 col-md-12 col-lg-12">
            <?php if(session('status')): ?>
                <div class="alert alert-info">
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>
        </div>
    </div>

    <div class="container">
        <div class="card text-center mb-5 shadow-sm mt-4">
            <div class="card-header">
                Jadwal Daftar Hadir
            </div>
            <div class="card-body">
                <div class="container">
                    <div class="row mt-4 justify-content-center">

                        <?php $__currentLoopData = $jadwal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-11 mb-5 shadow-sm">
                                <div class="card border-primary mb-3">
                                    <div class="card-header border-primary card-title font-weight-bold">
                                        <?php echo e($item->eskul->eskul_nama); ?>

                                    </div>
                                    <div class="card-body text-primary">
                                        <h5 class="card-title"><?php echo e($item->jadwal_tempat); ?></h5>
                                        <p class="card-text h6"><?php echo e(date('d, M Y', strtotime($item->jadwal_waktu))); ?>

                                            (<?php echo e(date('H:i', strtotime($item->jadwal_waktu))); ?>)</p>
                                    </div>
                                    <form action="<?php echo e(route('client-cek-absen', $item->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-success mb-3">
                                            Klik Untuk Daftar Hadir
                                        </button>
                                    </form>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <div class="col-12 mb-5 shadow-sm">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <br />
    <br />
    <br />
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.client-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\fathurwalkers\Desktop\htdocs\aplikasi-eskul\resources\views/client/client-absen.blade.php ENDPATH**/ ?>