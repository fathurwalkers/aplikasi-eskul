<?php $__env->startSection('tombol-keluar'); ?>
    <div class="tombol-keluar mt-2">
        <a href="<?php echo e(route('client')); ?>">
            <i class="bi bi-arrow-left-circle" style="font-size: 2rem; margin-right: 30px;"></i>
        </a>
        <h5 style="display: inline-block;">Jadwal Ekstrakulikuler</h5>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>

    <div class="container">
        <div class="row row-cols-2 row-cols-2 mt-4">

            <?php $__currentLoopData = $eskul; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-6 mb-5 shadow-sm">
                    <div class="card border-primary h-100 text-right">
                        <img src="<?php echo e(asset('assets')); ?>/<?php echo e($item->eskul_gambar); ?>" class="card-img-top" alt="..." />
                        <div class="card-body">
                            <h6 class="card-title font-weight-bold"><?php echo e($item->eskul_nama); ?></h6>
                            <a href="<?php echo e(route('client-mendaftar-eskul', $item->id)); ?>" class="btn btn-primary btn-sm">Daftar</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>

    <br />
    <br />
    <br />
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.client-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\fathurwalkers\Desktop\htdocs\aplikasi-eskul\resources\views/client/client-menu-daftar-eskul.blade.php ENDPATH**/ ?>