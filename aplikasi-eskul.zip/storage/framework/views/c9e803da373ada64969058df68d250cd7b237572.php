<div>
    <nav class="navbar navbar-expand navbar-light bg-navbar topbar mb-4 static-top">
        <button id="sidebarToggleTop" class="btn btn-link rounded-circle mr-3">
            <i class="fa fa-bars"></i>
        </button>
        <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-12">
                <img class="img-profile rounded-circle mr-1"
                        src="<?php echo e(asset('assets')); ?>/Logo-Tut-Wuri.png" style="max-width: 40px">
            </div>
        </div>
        <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-12">
                <h5 class="my-auto ml-2 text-white">
                    <b> SISTEM INFORMASI EKSTRAKULIKULER SMA NEGERI 2 BAUBAU </b>
                </h5>
            </div>
        </div>

        <ul class="navbar-nav ml-auto">
            
            
            
            <div class="topbar-divider d-none d-sm-block"></div>
            <li class="nav-item dropdown no-arrow">
                <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <img class="img-profile rounded-circle"
                        src="<?php echo e(asset('assets/ruangadmin')); ?>/img/boy.png" style="max-width: 60px">
                    <span class="ml-2 d-none d-lg-inline text-white small"><?php echo e($users->login_nama); ?></span>
                </a>
                <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in"
                    aria-labelledby="userDropdown">
                    <a class="dropdown-item" href="#">
                        <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                        Profile
                    </a>
                    
                    <div class="dropdown-divider"></div>

                    <a class="dropdown-item" href="javascript:void(0);" data-toggle="modal"
                        data-target="#logoutModal">
                        <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                        Logout
                    </a>

                </div>
            </li>
        </ul>
    </nav>
</div>
<?php /**PATH C:\Users\fathurwalkers\Desktop\htdocs\aplikasi-eskul\resources\views/components/dashboard-topbar.blade.php ENDPATH**/ ?>