<?php $__env->startSection('title', 'Dashboard - Daftar Siswa'); ?>

<?php $__env->startPush('css'); ?>
    <link href="<?php echo e(asset('datatables')); ?>/datatables.min.css" rel="stylesheet">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content-title', 'Dashboard - Daftar Siswa'); ?>


<?php $__env->startSection('main-content'); ?>

    <div class="row mt-1 mb-1">
        <div class="col-sm-12 col-md-12 col-lg-12">
            <?php if(session('status')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>
        </div>
    </div>

    <div class="row">
        <div class="col-sm-12 col-md-12 col-lg-12">
            <div class="card mb-3">
                <div class="card-body">
                    <div class="container">
                        <div class="row">
                            <h4>
                                <b>
                                    Daftar Siswa - Eskul (<?php echo e($eskul->eskul_nama); ?>)
                                </b>
                            </h4>
                        </div>
                        <hr />
                        <div class="row">
                            <div class="table-responsive">
                                <table id="example" class="display table-bordered" style="width:100%">
                                    <thead class="thead-dark">
                                        <tr>
                                            <th>No.</th>
                                            <th>Nama</th>
                                            <th>NISN</th>
                                            <th>Jenis Kelamin</th>
                                            <th>No. Telepon</th>
                                            <th>Status</th>
                                            <th>Kelas</th>
                                            <th>Ekstrakulikuler</th>
                                            <th>Kelola</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td class="text-center"><?php echo e($loop->iteration); ?></td>
                                                <td><?php echo e($item->siswa_nama); ?></td>
                                                <td><?php echo e($item->siswa_nisn); ?></td>
                                                <td>
                                                    <?php switch($item->siswa_jeniskelamin):
                                                        case ("L"): ?>
                                                            Laki - Laki
                                                            <?php break; ?>
                                                        <?php case ("P"): ?>
                                                            Perempuan
                                                            <?php break; ?>
                                                    <?php endswitch; ?>
                                                </td>
                                                <td><?php echo e($item->siswa_telepon); ?></td>
                                                <td><?php echo e($item->siswa_status); ?></td>
                                                <td><?php echo e($item->kelas->kelas_nama); ?></td>
                                                <?php if($item->eskul_id == NULL): ?>
                                                    <td>Belum Terdaftar</td>
                                                <?php else: ?>
                                                    <td><?php echo e($item->eskul->eskul_nama); ?></td>
                                                <?php endif; ?>
                                                <td>
                                                    <div class="row">
                                                        <div
                                                            class="col-sm-12 col-md-12 col-lg-12 d-flex justify-content-center mx-auto">
                                                            <button class="btn btn-sm btn-primary mr-1">Lihat</button>
                                                            <?php if($users->login_level == "admin"): ?>
                                                            <button href="#" class="btn btn-sm btn-success mr-1">Ubah</button>
                                                            <button href="#" class="btn btn-sm btn-danger">Hapus</button>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php $__env->startPush('js'); ?>
    <script src="<?php echo e(asset('datatables')); ?>/datatables.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#example').DataTable();
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.dashboard-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\fathurwalkers\Desktop\htdocs\aplikasi-eskul\resources\views/dashboard/lihat-eskul.blade.php ENDPATH**/ ?>