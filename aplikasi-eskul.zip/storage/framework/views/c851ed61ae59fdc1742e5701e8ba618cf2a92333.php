<?php $__env->startPush('css'); ?>
    <style>
        /* .container {
            height: 800px!important;
        } */
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('tombol-keluar'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
    <div class="row row-cols-1  justify-content-center">

        <?php if($siswa->eskul_id == null): ?>
        <div class="col-10 mb-4 btn shadow ">
            <a href="<?php echo e(route('client-menu-daftar-eskul')); ?>">
                <div class="card border-primary ">
                    <div class="card-body text-left">
                        <button type="button" class="btn btn-primary btn-sm">
                            <i class="bi bi-box-arrow-in-right" style="font-size: 1rem; display:inline-block;"></i>
                        </button>
                        <h6 class="card-title font-weight-bold"
                            style="font-size: 1rem; display: inline-block; margin-left: 40px;">Mendaftar</h6>
                    </div>
                </div>
            </a>
        </div>
        <?php endif; ?>

        <div class="col-10 mb-4 btn shadow">
            <a href="<?php echo e(route('client-daftar-jadwal')); ?>">
                <div class="card border-warning  ">
                    <div class="card-body text-left">
                        <button type="button" class="btn btn-warning btn-sm">
                            <i class="bi bi-list-stars text-light" style="font-size: 1rem; display:inline-block;"></i>
                        </button>
                        <h6 class="card-title font-weight-bold text-warning"
                            style=" font-size: 1rem; display: inline-block; margin-left: 40px;">Jadwal</h6>
                    </div>
                </div>
            </a>
        </div>
        <div class="col-10 mb-4 btn shadow">
            <a href="<?php echo e(route('client-daftar-eskul')); ?>">
                <div class="card border-danger ">
                    <div class="card-body text-left">
                        <button type="button" class="btn btn-danger btn-sm">
                            <i class="bi bi-activity" style="font-size: 1rem; display:inline-block;"></i>
                        </button>
                        <h6 class="card-title font-weight-bold text-danger"
                            style="font-size: 1rem; display: inline-block; margin-left: 40px;">Kegiatan</h6>
                    </div>
                </div>
            </a>
        </div>
        <div class="col-10 mb-4 btn shadow">
            <a href="<?php echo e(route('client-prestasi-eskul')); ?>">
                <div class="card border-info ">
                    <div class="card-body text-left">
                        <button type="button" class="btn btn-info btn-sm">
                            <i class="bi bi-star-fill" style="font-size: 1rem; display:inline-block;"></i>
                        </button>
                        <h6 class="card-title font-weight-bold text-info"
                            style="font-size: 1rem; display: inline-block; margin-left: 40px;">Prestasi Extraculicullar</h6>
                    </div>
                </div>
            </a>
        </div>
        
        <div class="col-10 mb-4 btn shadow">
            <a href="<?php echo e(asset('assets/client')); ?>/nilaiSiswa.html">
                <div class="card border-warning ">
                    <div class="card-body text-left">
                        <button type="button" class="btn btn-warning btn-sm">
                            <i class="bi bi-123 text-light" style="font-size: 1rem; display:inline-block;"></i>
                        </button>
                        <h6 class="card-title font-weight-bold text-warning"
                            style="font-size: 1rem; display: inline-block; margin-left: 40px;">Nilai Siswa</h6>
                    </div>
                </div>
            </a>
        </div>
        <div class="col-10 mb-1 btn shadow">
            <a href="<?php echo e(asset('assets/client')); ?>/absen.html">
                <div class="card border-primary ">
                    <div class="card-body text-left">
                        <button type="button" class="btn btn-primary btn-sm">
                            <i class="bi bi-person-check" style="font-size: 1rem; display:inline-block;"></i>
                        </button>
                        <h6 class="card-title font-weight-bold text-primary"
                            style="font-size: 1rem; display: inline-block; margin-left: 40px;">Absen</h6>
                    </div>
                </div>
            </a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.client-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\fathurwalkers\Desktop\htdocs\aplikasi-eskul\resources\views/client/index.blade.php ENDPATH**/ ?>